(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[79],{

/***/ 3285:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("import { formatBytes32String, parseBytes32String } from \"./bytes32\";\nimport { nameprep } from \"./idna\";\nimport { _toEscapedUtf8String, toUtf8Bytes, toUtf8CodePoints, toUtf8String, UnicodeNormalizationForm, Utf8ErrorFunc, Utf8ErrorFuncs, Utf8ErrorReason } from \"./utf8\";\nexport { _toEscapedUtf8String, toUtf8Bytes, toUtf8CodePoints, toUtf8String, Utf8ErrorFunc, Utf8ErrorFuncs, Utf8ErrorReason, UnicodeNormalizationForm, formatBytes32String, parseBytes32String, nameprep };\n//# sourceMappingURL=index.d.ts.map");

/***/ })

}]);
//# sourceMappingURL=raw-loader!-ethersproject-strings-lib-index-d-ts.0.26.0-dev.1660932101910.js.map
//# sourceMappingURL=raw-loader!-ethersproject-strings-lib-index-d-ts.0.26.0-dev.1660932101910.js.map